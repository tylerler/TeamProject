object ThisIsHard {
def killMe(): Unit ={
  println("make it stop")
}
}
